# AoXdeface
Pastikan Script Deface di simpan dalam file AoXdeface
